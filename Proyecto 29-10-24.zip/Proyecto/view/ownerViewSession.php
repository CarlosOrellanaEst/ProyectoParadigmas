<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Texto Simple</title>
</head>
<body>
    <p>PAGINA DE PROPIETARIO.</p>
    <ol>
        <li><a href="paymentTypeView.php">CRUD Tipo de Pago</a></li>
        <li><a href="ownerView.php">CRUD Propietarios</a></li>
        <li><a href="touristCompanyView.php">CRUD Empresas turísticas</a></li>
        <li><a href="activityView.php">CRUD Actividades</a></li>
<!--         <li><a href="./view/pruebas.php">Pruebas</a></li>
        <li><a href="./view/serviceView.php">CRUD Servicios</a></li> -->
    </ol>
    <?php 
       echo ' <a href="../index.php">Cerrar Sesión</a> ';
       $_SESSION = array();
    //   session_destroy();
    ?>
</body>
</html>
